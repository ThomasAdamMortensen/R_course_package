#################### 8.1
set.seed(42)
n <- 2000
knapsack_objects <- data.frame(w = sample(1:4000, size = n, replace = TRUE), v = runif(n = n, 0, 10000))

brute_force_knapsack = function(x, W){
  if(!is.data.frame(x) || sum(x["v"] <= 0) || sum(x["w"] <= 0) || !is.numeric(W))
  {
    stop("Ensure W is numeric and x is a df with positive num cols named v")
  }
  weights = x[["w"]]
  values = x[["v"]]
  n <- length(values)

  # Init vars to track the best value and combination
  best_value <- 0
  best_subset <- NULL

  # Iterate over all possible subsets (from 0 to 2^n - 1)
  for (subset in 0:(2^n - 1)) {
    # Get the binary representation of the subset
    # For the the subset with just item 1 it would be: 01 00 00.....
    bits <- intToBits(subset)

    # set value, weight and index of items for current subset
    total_value <- 0
    total_weight <- 0
    current_subset = c()
    for (i in 1:n) {
      if (bits[i] == 1) {
        # Item i is included in this subset
        # Remember if for ex item 1 is included we will eval to true when bits[1] == 1
        # as bits[1] == 01 == 1 so we evaluate that to true and add its val/weight/index
        total_value <- total_value + values[i]
        total_weight <- total_weight + weights[i]
        current_subset <- c(current_subset, i)
      }
    }

    # Check if subset is valid(weight <= knapsack capacity) and best yet value-wise
    if (total_weight <= W && total_value > best_value) {
      best_value <- total_value
      best_subset <- current_subset
    }
  } # We do this process for all items for every subset

  # Display the best result
  return(list(value = best_value, elements = best_subset))

}
brute_force_knapsack(x = knapsack_objects[1: 8,], 3500)
brute_force_knapsack(x = knapsack_objects[1:12,], W = 3500)
brute_force_knapsack(x = knapsack_objects[1:8,], W = 2000)
brute_force_knapsack(x = knapsack_objects[1:12,], W = 2000)

system.time(brute_force_knapsack(x = knapsack_objects[1:16,], W = 2000)) # About 0.23 seconds on this PC for n = 16





#################### 8.2

greedy_knapsack = function(x, W){
  if(!is.data.frame(x) || sum(x["v"] <= 0) || sum(x["w"] <= 0) || !is.numeric(W))
  {
    stop("Ensure W is numeric and x is a df with positive num cols named v")
  }
  val_wt = x$v/x$w
  x = x[order(val_wt, decreasing = TRUE),]
  n <- nrow(x)
  current_val = 0
  rem_W = W
  elem = c()
  for(i in 1:n){
    if(x[i,"w"] <= rem_W){
      rem_W = rem_W - x[i,"w"]
      current_val = current_val + x[i,"v"]
      elem = c(elem, as.numeric(rownames(x[i,])))
    }
  }
  return(list(value = current_val, elements = elem))
}

greedy_knapsack(x = knapsack_objects[1:800,], W = 3500)
greedy_knapsack(x = knapsack_objects[1:1200,], W = 2000)

n1 <- 1e6
knapsack_objects1 <- data.frame(w = sample(1:4000, size = n1, replace = TRUE), v = runif(n = n1, 0, 10000))
system.time(greedy_knapsack(knapsack_objects1, W = 2000))
# Running the algo for 1e6 objects takes 4.8 seconds on this PC

#################### 8.3
library(profvis)
profvis({
  x = knapsack_objects1
  W = 2000
  val_wt = x$v/x$w
  x = x[order(val_wt, decreasing = TRUE),]
  n <- nrow(x)
  current_val = 0
  rem_W = W
  elem = c()
  for(i in 1:n){
    if(x[i,"w"] <= rem_W){
      rem_W = rem_W - x[i,"w"]
      current_val = current_val + x[i,"v"]
      elem = c(elem, as.numeric(rownames(x[i,])))
    }
  }
  return(list(value = current_val, elements = elem))
})
# First here it takes 3 entire seconds just for the conditional
# Indexing a dataframe is very expensive in R compared to a vector, lets change that!

profvis({
  x = knapsack_objects1
  W = 2000
  val_wt = x$v/x$w
  x = x[order(val_wt, decreasing = TRUE),]
  n <- nrow(x)
  current_val = 0
  rem_W = W
  elem = c()
  w_vec = x[["w"]]
  v_vec = x[["v"]]
  for(i in 1:n){
    if(w_vec[i] <= rem_W){
      rem_W = rem_W - w_vec[i]
      current_val = current_val + v_vec[i]
      elem = c(elem, as.numeric(rownames(w_vec[i])))
    }
  }
  list(value = current_val, elements = elem)

})
# Now it take 50ms instead of almost 3000, a huge improvement!

greedy_knapsack_improved = function(x, W){
  if(!is.data.frame(x) || sum(x["v"] <= 0) || sum(x["w"] <= 0) || !is.numeric(W))
  {
    stop("Ensure W is numeric and x is a df with positive num cols named v")
  }
  val_wt = x$v/x$w
  x = x[order(val_wt, decreasing = TRUE),]
  n <- nrow(x)
  current_val = 0
  rem_W = W
  elem = c()
  w_vec = x[["w"]]
  v_vec = x[["v"]]
  for(i in 1:n){
    if(w_vec[i] <= rem_W){
      rem_W = rem_W - w_vec[i]
      current_val = current_val + v_vec[i]
      elem = c(elem, as.numeric(rownames(w_vec[i])))
    }
  }
  return(list(value = current_val, elements = elem))
}
system.time(greedy_knapsack_improved(knapsack_objects1, W = 2000))
# Changing the conditional to use vectors made this take 4.72 seconds less on my machine.
# Which is a huge improvement, reducing execution time by about 98 %

############## 8.4

library(roxygen2)
library(devtools)
#' Brute-force Knapsack
#'
#' @param x A df with two numeric cols named v and w
#' @param W A numeric scalar of length 1
#' @description
#' A brute-force approach to the knapsack problem, always gets the optimal solution, O(2^N) time complexity, in short very expensive computationally.
#' @return A list with Value and indexes of best combination of items
#' @export
#'
#' @examples
#' set.seed(1)
#' brute_force_knapsack(data.frame(w = sample(1:4000, size = 10, replace = TRUE), v = runif(n = 10, 0, 10000)), W = 2000)
brute_force_knapsack = function(x, W){
  if(!is.data.frame(x) || sum(x["v"] <= 0) || sum(x["w"] <= 0) || !is.numeric(W))
  {
    stop("Ensure W is numeric and x is a df with positive num cols named v")
  }
  weights = x[["w"]]
  values = x[["v"]]
  n <- length(values)

  # Init vars to track the best value and combination
  best_value <- 0
  best_subset <- NULL

  # Iterate over all possible subsets (from 0 to 2^n - 1)
  for (subset in 0:(2^n - 1)) {
    # Get the binary representation of the subset
    # For the the subset with just item 1 it would be: 01 00 00.....
    bits <- intToBits(subset)

    # set value, weight and index of items for current subset
    total_value <- 0
    total_weight <- 0
    current_subset = c()
    for (i in 1:n) {
      if (bits[i] == 1) {
        # Item i is included in this subset
        # Remember if for ex item 1 is included we will eval to true when bits[1] == 1
        # as bits[1] == 01 == 1 so we evaluate that to true and add its val/weight/index
        total_value <- total_value + values[i]
        total_weight <- total_weight + weights[i]
        current_subset <- c(current_subset, i)
      }
    }

    # Check if subset is valid(weight <= knapsack capacity) and best yet value-wise
    if (total_weight <= W && total_value > best_value) {
      best_value <- total_value
      best_subset <- current_subset
    }
  } # We do this process for all items for every subset

  # Display the best result
  return(list(value = best_value, elements = best_subset))

}

#' Greedy Knapsack
#'
#' @param x A df with two numeric cols named v and w
#' @param W A numeric scalar of length 1
#' @description
#' A much faster than the brute force approach to the knapsack problem,
#' sorts items by value to weight ratio and fills sack as long as capacity is not reached
#'
#' @return A list with Value and indexes of best combination of items
#' @export
#'
#' @examples
#' set.seed(1)
#' greedy_knapsack_improved(data.frame(w = sample(1:4000, size = 20, replace = TRUE), v = runif(n = 20, 0, 10000)), 3500)
greedy_knapsack_improved = function(x, W){
  if(!is.data.frame(x) || sum(x["v"] <= 0) || sum(x["w"] <= 0) || !is.numeric(W))
  {
    stop("Ensure W is numeric and x is a df with positive num cols named v")
  }
  val_wt = x$v/x$w
  x = x[order(val_wt, decreasing = TRUE),]
  n <- nrow(x)
  current_val = 0
  rem_W = W
  elem = c()
  w_vec = x[["w"]]
  v_vec = x[["v"]]
  for(i in 1:n){
    if(w_vec[i] <= rem_W){
      rem_W = rem_W - w_vec[i]
      current_val = current_val + v_vec[i]
      elem = c(elem, as.numeric(rownames(x[i,])))
    }
  }
  return(list(value = current_val, elements = elem))
}

# Might have to uncomment these and run them in order to make the doc examples to work
# Make sure install gets to run fully
#install()
#library(myKnapsack)
#?greedy_knapsack_improved
#?brute_force_knapsack
